﻿import "./config/env.js";
import express from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import { initializeFirebase } from "./config/firebase.js";
import compression from "compression";

/* ── Global Error Handlers ── */
// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
  console.error('❌ Uncaught Exception:', error.message);
  // Don't exit for MongoDB connection errors
  if (!error.message?.includes('getaddrinfo') && !error.message?.includes('ENOTFOUND')) {
    console.error('Stack:', error.stack);
    process.exit(1);
  }
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  const errorMsg = reason?.message || String(reason);
  // MongoDB connection errors shouldn't crash the server
  if (errorMsg?.includes('getaddrinfo') || errorMsg?.includes('ENOTFOUND') || errorMsg?.includes('ETIMEDOUT')) {
    console.warn('⚠️  MongoDB connection issue detected - will retry on next request');
  } else {
    console.error('❌ Unhandled Promise Rejection:', errorMsg);
  }
});

/* ── Main DB ── */
import connectMainDB from "./config/mainDb.js";

/* ── Main/Public Routes ── */
import tenantRoutes              from "./routes/tenant.routes.js";
import mainUserRoutes            from "./routes/mainUser.routes.js";
import subscriptionPlanRoutes    from "./routes/Subscription.routes.js";
import createAdminRoutes         from "./routes/adminRoutes.js";
import subscriptionRoutes        from "./routes/TenantSubscriptionRoutes.js";
import saasRoutes                from "./routes/DashboardRoutes.js";
import monthlyBillingRoutes      from "./routes/MonthlyBillingRoutes.js";
import freeTrialPackageRoutes    from "./routes/FreeTrialPackage.routes.js";
import distributorRoutes         from "./routes/distributor.routes.js";
import faqRoutes                 from "./routes/faqRoutes.js";
import contactRoutes             from "./routes/contactRoutes.js";
import siteSettingsRoutes        from "./routes/siteSettingsRoutes.js";
import uploadRoutes              from "./routes/uploadRoutes.js";
import supplierRoutes            from "./routes/SupplierRoutes.js";

/* ── Tenant Middleware ── */
import { tenantMiddleware }  from "./middleware/tenant.middleware.js";
import { dbMiddleware }      from "./middleware/db.middleware.js";
import { subscriptionGuard } from "./middleware/subscriptionGuard.js";

/* ── Tenant Routes ── */
import tenantAuthRoutes         from "./routes/tenant/auth/tenantUserLoginRoutes.js";
import userManagementRoutes     from "./routes/tenant/userManagementRoutes.js";
import roleRoutes               from "./routes/tenant/roleRoutes.js";
import tenantSubscriptionRoutes from "./routes/tenantSelfSubscriptionRoutes.js";

/* ── Franchise Login controller ── */
import { franchiseLogin } from "./controllers/tenant.controller.js";

/* ─────────────────────────────────────────── */
const app = express();
app.use(compression());
app.use(express.json());
app.use(cookieParser());

/* ── CORS ── */
const allowedOrigins = (process.env.CLIENT_URL || '')
  .split(',').map(u => u.trim()).filter(Boolean);

app.use(cors({
  origin: (origin, callback) => {
    if (!origin) return callback(null, true);
    if (
      /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin) ||
      /^https?:\/\/[^.]+\.localhost(:\d+)?$/.test(origin)
    ) return callback(null, true);
    if (allowedOrigins.includes('*')) return callback(null, true);
    if (allowedOrigins.includes(origin)) return callback(null, true);
    const baseDomain = process.env.BASE_DOMAIN || '';
    if (baseDomain && origin.endsWith(`.${baseDomain}`)) return callback(null, true);
    return callback(new Error(`CORS: origin '${origin}' not allowed`));
  },
  credentials: true,
  allowedHeaders: ['Content-Type', 'Authorization', 'x-tenant-id', 'Cache-Control', 'Pragma'],
  exposedHeaders: [
    'X-Subscription-Status', 'X-Subscription-Days-Left', 'X-Subscription-Used',
    'X-Subscription-Limit', 'X-Subscription-Usage-Pct', 'X-Subscription-Paid',
    'X-Subscription-Warnings',
  ],
}));

/* ── Connect DB + Firebase in parallel ── */
Promise.all([
  connectMainDB(),
  Promise.resolve(initializeFirebase()),
]).catch((err) => {
  console.error("❌ Startup initialization failed:", err.message);
  process.exit(1);
});

/* ── Serve Static Files (uploaded images) ── */
app.use('/uploads', express.static('uploads'));

/* ══════════════════════════════════════════
   PUBLIC ROUTES (no tenant context)
══════════════════════════════════════════ */
// Health check
app.get("/", (req, res) => {
  res.json({ 
    success: true, 
    message: "Franchise Backend API ✅", 
    version: "2.0.0",
    timestamp: new Date().toISOString()
  });
});

app.get("/api/health", (req, res) => {
  res.json({ 
    success: true, 
    status: "healthy", 
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    timestamp: new Date().toISOString()
  });
});

// Setup routes (one-time Super Admin creation)
import setupRoutes from "./routes/setup.routes.js";
app.use("/api/setup", setupRoutes);

app.use("/api/mainUser",            mainUserRoutes);
// SuperAdmin login — public, no tenant context needed
// Frontend calls: POST /api/auth/superadmin/login
app.use("/api/auth/superadmin",     mainUserRoutes);
app.use("/api/schools",             tenantRoutes);
app.use("/api/distributor",         distributorRoutes);
app.use("/api/subscriptionPlan",    subscriptionPlanRoutes);
app.use("/api/upload",              uploadRoutes);
app.use("/api/saas",                saasRoutes);
app.use("/api/monthly-billing",     monthlyBillingRoutes);
app.use("/api/faq",                 faqRoutes);
app.use("/api/contact",             contactRoutes);
app.use("/api/site-settings",       siteSettingsRoutes);
app.use("/api/subscription",        subscriptionRoutes);
app.use("/api/free-trial-packages", freeTrialPackageRoutes);
app.use("/api/suppliers",           supplierRoutes);

/* Franchise Supplier routes - BEFORE tenant middleware (uses main DB suppliers) */
import franchiseSupplierRoutes from "./routes/FranchiseSupplierRoutes.js";
app.use("/api/franchise-suppliers", franchiseSupplierRoutes);

/* Master Medicine routes - Public for autocomplete */
import masterMedicineRoutes from "./routes/MasterMedicineRoutes.js";
app.use("/api/master-medicines", masterMedicineRoutes);

/* Medicine Master routes - Superadmin only (global medicines) */
import medicineMasterRoutes from "./routes/MedicineMasterRoutes.js";
// ❌ MUST come BEFORE dbMiddleware - SuperAdmin doesn't have tenant context
app.use("/api/superadmin/medicines", medicineMasterRoutes);

/* ══════════════════════════════════════════
   MULTI-TENANT MIDDLEWARE
══════════════════════════════════════════ */
app.use(tenantMiddleware);
app.use(dbMiddleware);

/* Subscription Guard */
app.use((req, res, next) => {
    const url = req.originalUrl;
    const exempted = [
        "/api/auth",
        "/api/subscription-status",
        "/api/my-subscription",
    ];
    const isExempt = exempted.some(path => url.startsWith(path));
    if (isExempt) return next();
    return subscriptionGuard(req, res, next);
});

/* Real-time subscription status */
app.get("/api/subscription-status", async (req, res) => {
  if (!req.tenant) return res.status(400).json({ success: false, message: "No tenant context" });
  try {
    const { default: TenantSubscription } = await import("./models/TenantSubscription.modal.js");
    const sub = await TenantSubscription.findOne({ tenantId: req.tenant._id }).lean();
    if (!sub) return res.status(200).json({ success: true, data: { hasSubscription: false } });

    const now      = new Date();
    const endDate  = sub.currentPlan?.endDate;
    const daysLeft = endDate ? Math.ceil((new Date(endDate) - now) / 86400000) : null;

    const warnings = [];
    if (daysLeft !== null && daysLeft <= 30 && daysLeft > 0) warnings.push("EXPIRING_SOON");
    if (daysLeft !== null && daysLeft <= 0)                  warnings.push("EXPIRED");
    if (sub.paidStatus === "OVERDUE")                         warnings.push("PAYMENT_OVERDUE");
    if (sub.paidStatus === "UNPAID")                          warnings.push("PAYMENT_UNPAID");

    return res.status(200).json({
      success: true,
      data: {
        hasSubscription: true,
        status:          sub.status,
        planName:        sub.currentPlan?.name,
        billingCycle:    sub.currentPlan?.billingCycle,
        endDate,
        daysLeft:        daysLeft !== null ? Math.max(0, daysLeft) : null,
        totalAmount:     sub.totalAmount || 0,
        paidStatus:      sub.paidStatus,
        dueDate:         sub.dueDate,
        warnings,
      },
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
});

/* ══════════════════════════════════════════
   TENANT ROUTES
══════════════════════════════════════════ */
app.use("/api/auth",            tenantAuthRoutes);
app.use("/api/users",           userManagementRoutes);
app.use("/api/roles",           roleRoutes);
app.post("/api/franchise/login", franchiseLogin);

/* ================= FRANCHISE MODULE ROUTES ================= */
import franchiseDashboardRoutes from "./routes/tenant/franchise/dashboardRoutes.js";
import franchiseSalesRoutes     from "./routes/tenant/franchise/salesRoutes.js";
import franchisePurchaseRoutes  from "./routes/tenant/franchise/purchaseRoutes.js";
import franchiseInventoryRoutes from "./routes/tenant/franchise/inventoryRoutes.js";
import franchisePosRoutes       from "./routes/tenant/franchise/posRoutes.js";
import franchiseFullPurchaseRoutes  from "./routes/tenant/franchise/fullPurchaseRoutes.js";
import franchiseFullInventoryRoutes from "./routes/tenant/franchise/fullInventoryRoutes.js";
import franchiseLiveRatesRoutes     from "./routes/tenant/franchise/liveRatesRoutes.js";
import franchiseRemainingRoutes     from "./routes/tenant/franchise/remainingRoutes.js";
import franchiseMasterRoutes        from "./routes/tenant/franchise/masterRoutes.js";
import globalMedicineRoutes         from "./routes/tenant/franchise/globalMedicineRoutes.js";
// ❌ REMOVED: Tenant supplier routes (deleted - using global suppliers only)
// import franchiseSupplierRoutesNew   from "./routes/tenant/franchise/supplierRoutes.js";

app.use("/api/franchise/dashboard",   franchiseDashboardRoutes);
app.use("/api/franchise/sales",       franchiseSalesRoutes);
// app.use("/api/franchise/purchase",    franchisePurchaseRoutes); // ← Disabled: Using fullPurchaseRoutes instead
app.use("/api/franchise/purchase",    franchiseFullPurchaseRoutes);
app.use("/api/franchise/inventory",   franchiseInventoryRoutes);
app.use("/api/franchise/inventory",   franchiseFullInventoryRoutes);
app.use("/api/franchise/pos",         franchisePosRoutes);
app.use("/api/franchise/live-rates",  franchiseLiveRatesRoutes);
app.use("/api/franchise/master",      franchiseMasterRoutes);
app.use("/api/franchise/medicines",   globalMedicineRoutes);
// ❌ REMOVED: app.use("/api/franchise/suppliers", franchiseSupplierRoutesNew);

// ✅ Supplier orders route for franchise portal (uses global suppliers + tenant POs)
app.use("/api/franchise/suppliers", supplierRoutes);

app.use("/api/franchise",             franchiseRemainingRoutes);

/* Tenant's own subscription info */
app.use("/api/my-subscription", tenantSubscriptionRoutes);
app.use("/api/admins",          createAdminRoutes);

/* ── Fallback ── */
app.use("/api", (_req, res) => res.send("Franchise API working ✅"));

/* ── Global Error Handler ── */
app.use((err, req, res, next) => {
  console.error("Unhandled Error:", err?.message || err);
  const status  = err?.statusCode || err?.status || 500;
  const message = err?.error?.description
    ? `Payment gateway error: ${err.error.description}`
    : (err?.message || "Internal Server Error");
  res.status(typeof status === 'number' ? status : 500).json({
    statusCode: status, success: false, message, data: null,
  });
});

/* ── Server ── */
const PORT = process.env.PORT || 5001;
app.listen(PORT, () => console.log(`🚀 Franchise server running on port ${PORT}`));
